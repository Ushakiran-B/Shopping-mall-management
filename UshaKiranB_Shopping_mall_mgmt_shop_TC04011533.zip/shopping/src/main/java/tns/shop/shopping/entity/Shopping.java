package tns.shop.shopping.entity;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="Shopping")
public class Shopping {
	@Id
	@GeneratedValue
	long id;
	String category;
	long employeeID;
	String Name;
	String customers;
	String Status1;
	String owner;
	String Status;
	public Shopping() {
		super();
	}
	public Shopping(long id, String category, long employeeID, String name, String customers, String status1, String owner,
			String status) {
		super();
		this.id = id;
		this.category = category;
		this.employeeID = employeeID;
		Name = name;
		this.customers = customers;
		Status1 = status1;
		this.owner = owner;
		Status = status;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public long getEmployeeID() {
		return employeeID;
	}
	public void setEmployeeID(long employeeID) {
		this.employeeID = employeeID;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getCustomers() {
		return customers;
	}
	public void setCustomers(String customers) {
		this.customers = customers;
	}
	public String getStatus1() {
		return Status1;
	}
	public void setStatus1(String status1) {
		Status1 = status1;
	}
	public String getOwner() {
		return owner;
	}
	public void setOwner(String owner) {
		this.owner = owner;
	}
	public String getStatus() {
		return Status;
	}
	public void setStatus(String status) {
		Status = status;
	}


}

