package tns.shop.shopping.controller;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import tns.shop.shopping.entity.Shopping;
import tns.shop.shopping.service.ShoppingService;
@RestController
public class ShoppingController {
    @Autowired
	ShoppingService shoppingService;
	// http://localhost:8036/shopping - Post
	@RequestMapping("/shopping")
	@PostMapping
	public Shopping addShop(@RequestBody Shopping shopping)
	{
	return shoppingService.save(shopping);
	}
	// http://localhost:8036/shopping/2 - Get
	@GetMapping(path="/{id}")
	public Shopping getShopping(@PathVariable long id)
	{
	return shoppingService.getShopping(id);
	}
	// http://localhost:8036/shopping/2 - Put
	@PutMapping(path="/{id}")
	public Shopping updateShopping(@RequestBody Shopping shopping, @PathVariable long id)
	{
	return shoppingService.update(id,shopping);
	}
	// http://localhost:8036/shopping/2 - delete
	@DeleteMapping(path="/{id}")
	public String deleteShopping(@PathVariable int id)
	{
	return shoppingService.delete(id); 
	}
	// http://localhost:8036/shopping Get
	@GetMapping
	public List<Shopping> getAllShopping()
	{
	return shoppingService.getShoplist();
	}
	}




